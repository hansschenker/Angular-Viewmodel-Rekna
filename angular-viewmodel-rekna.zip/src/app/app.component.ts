import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, scan, tap } from 'rxjs/operators';
import { Observable, merge, Subject } from 'rxjs';


interface IUser {
  id?:number;
  name:string;
}
interface IViewModel {
  users: IUser[];
  selectedUser?: IUser;
}

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  name = 'Angular';

  public vm$ : Observable<IViewModel>;
  public addUserSubj = new Subject<IUser>();
  public deleteUserSubj = new Subject<IUser>();
  public detailUserSubj = new Subject<IUser>();
  public closeDetailSubj = new Subject();

  constructor(private http:HttpClient) {

    this.vm$ = merge(
      this.getUserAction$,
      this.addUserAction$,
      this.deleteUserAction$,
      this.detailUserAction$,
      this.closeDetailAction$
    ).pipe(
      scan( (oldVm:IViewModel, mutateFn:(vm:IViewModel)=>IViewModel) => mutateFn(oldVm), {users:[]} as IViewModel )
    );

  }

  private getUserAction$ = this.http.get<IUser[]>(`https://jsonplaceholder.typicode.com/users`).pipe(
    map( users => (vm:IViewModel) => ({...vm, users}))

  );

  private addUserAction$ = this.addUserSubj.pipe(
    map( user => (vm:IViewModel) => ({...vm, users: [...vm.users ,{id:9, name:user}] })),
  )
  private deleteUserAction$ = this.deleteUserSubj.pipe(
    map( user => (vm:IViewModel) => ({...vm, users: vm.users.filter(u=>u!==user) }))
  )

  private detailUserAction$ = this.detailUserSubj.pipe(
    map( selectedUser => (vm:IViewModel) => ({...vm, selectedUser }))
  )
  private closeDetailAction$ = this.closeDetailSubj.pipe(
    map( _ => (vm:IViewModel) => ({...vm, selectedUser:null }))
  )

}
